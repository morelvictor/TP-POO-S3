class Image extends Media{
	int largeur, hauteur;

	public Image(String titre, int largeur, int hauteur){
		super(titre);
		this.largeur = largeur;
		this.hauteur = hauteur;
	}
	
}
