class Predicat{
	boolean estVrai(Media doc){
		return false;
	}
}
